"use client";

import { userAgent } from "next/server";
import PageHoc from "../components/PageHoc"
import styles from "../page.module.css"
import { useEffect, useState } from "react"

const Page = () => {
    const [menus, setMenus] = useState({});
    const [pedido, setPedido] = useState([]);

    useEffect(() => {
        fetch("http://localhost:1337/api/menus?populate=imagemProduto")
            .then(res => res.json())
            .then((res) => setMenus(res));
    }, []);

    useEffect(() => {
        console.log(pedido)
    }, [pedido]);

    const verificaPedido = (idMenu) => {
        let isInArray = false;
        pedido.forEach((elem)=>{
            if(idMenu == elem)
                isInArray = true
        });
        return isInArray;
    }

    const addOrDelete = (idMenu) => {
        if(verificaPedido(idMenu)){
            setPedido(pedido.filter((elem) => elem!=idMenu));
        }else{
            setPedido([...pedido, idMenu])
        }
    }


    const apresentaMenu = menus.data == undefined ? "" : menus.data.map((elem) => {
        const UrlImg = "http://localhost:1337"+elem.attributes.imagemProduto.data[0].attributes.url;

        return <div>
        <div className="card m-4" style={{ width: "18rem;" }}>
            <img className="card-img-top" src={UrlImg}/>
            <div className="card-body">
                <h5 className="card-title">{elem.attributes.Titulo}</h5>
                <p className="card-text">{elem.attributes.descricao}</p>
                <label>Pedir </label>
                <input type="checkbox" defaultChecked={verificaPedido(elem.id)} onChange={() => {addOrDelete(elem.id)}} />
            </div>
        </div>
    </div>
    });


    return <PageHoc>
        <main className={styles.main}>
            <div>
                <h4>Página de Menus</h4>
                <div className="d-flex">
                    {apresentaMenu}
                </div>
                <hr></hr>
                <center> <a href="#" className="btn btn-primary">Comprar</a> </center>
            </div>
        </main>
    </PageHoc>
}

export default Page; 