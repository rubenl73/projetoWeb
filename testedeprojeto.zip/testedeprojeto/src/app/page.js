import Head from 'next/head';
import styles from './styles/Home.module.css';
import Link from 'next/link';

export default function Home() {
  return (
    <div className={styles.container}>
      <Head>
        <title>FoodTruck RK</title>
        <meta name="description" content="Visite o FoodTruck RK para os melhores lanches!" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <header className={styles.header}>
        <img src="/logo.png" alt="Logotipo do FoodTruck RK" className={styles.logo} />
        <h1>FoodTruck RK</h1> 
        <br></br>
        <Link href="/admin" className={styles.loginButton}>Admin Login</Link>
      </header>

      <main className={styles.main}>
        <section className={styles.about}>
          <h2>Saudações</h2>
          <p>Encontre sabores incríveis e uma experiência gastronômica única no foodtruck RK. 
            Preparamos comida de rua com qualidade e um toque especial.</p>
        </section>

        <section className={styles.info}>
          <h2>Horário de Funcionamento:</h2>
          <p>Segunda a Quinta: 11h às 22h</p>
          <p>Sexta e Sábado: 12h às 24h</p>
        </section>

        <Link href="/menus" className={styles.menuButton}>Pedir Menu</Link>
      </main>

      <footer className={styles.footer}>
        <p>Visite-nos e experimente as nossas especialidades. Na sua rua mais próxima!</p>
        <br></br>
        <Link href="/pages" className={styles.menuButton}>Sobre Nos</Link>
      </footer>
    </div>
  )
}
