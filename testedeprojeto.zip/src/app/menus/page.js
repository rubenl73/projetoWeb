"use client";

import PageHoc from "../components/PageHoc";
import styles from "../page.module.css";
import { useEffect, useState } from "react";
import Link from 'next/link';

const Page = () => {
    const [menus, setMenus] = useState({});
    const [pedido, setPedido] = useState({});
    const [showForm, setShowForm] = useState(false);
    const [name, setName] = useState("");
    const [confirmation, setConfirmation] = useState(false);
    const [warning, setWarning] = useState(false);

    useEffect(() => {
        fetch("http://localhost:1337/api/menus?populate=imagemProduto")
            .then(res => res.json())
            .then((res) => setMenus(res));
    }, []);

    useEffect(() => {
        console.log(pedido);
    }, [pedido]);

    const verificaPedido = (idMenu) => {
        return pedido[idMenu] !== undefined;
    };

    const addOrDelete = (idMenu) => {
        if (verificaPedido(idMenu)) {
            const newPedido = { ...pedido };
            delete newPedido[idMenu];
            setPedido(newPedido);
        } else {
            setPedido({ ...pedido, [idMenu]: 1 });
        }
    };

    const updateQuantity = (idMenu, quantity) => {
        if (verificaPedido(idMenu)) {
            setPedido({ ...pedido, [idMenu]: quantity });
        }
    };

    const handleComprar = () => {
        if (Object.keys(pedido).length === 0) {
            setWarning(true);
        } else {
            setWarning(false);
            setShowForm(true);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const pedidoData = {
            name,
            menus: Object.keys(pedido).map(id => parseInt(id))
        };

        fetch("http://localhost:1337/api/pedidos", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ data: pedidoData })
        }).then((res) => {
            if (res.ok) {
                setShowForm(false);
                setConfirmation(true);
            }
        });
    };

    const apresentaMenu = menus.data == undefined ? "" : menus.data.map((elem) => {
        const UrlImg = "http://localhost:1337" + elem.attributes.imagemProduto.data[0].attributes.url;

        return (
            <div key={elem.id}>
                <div className="card m-4" style={{ width: "18rem" }}>
                    <img className="card-img-top" src={UrlImg} />
                    <div className="card-body">
                        <h5 className="card-title">{elem.attributes.Titulo}</h5>
                        <p className="card-text">{elem.attributes.descricao}</p>
                        <p className="card-text">{elem.attributes.preco}€</p>
                        <label>Pedir </label>
                        <input type="checkbox" checked={verificaPedido(elem.id)} onChange={() => { addOrDelete(elem.id) }} />
                        {verificaPedido(elem.id) && (
                            <>
                                <label> Quantidade: </label>
                                <input type="number" value={pedido[elem.id]} min="1" onChange={(e) => { updateQuantity(elem.id, parseInt(e.target.value)) }} />
                            </>
                        )}
                    </div>
                </div>
            </div>
        );
    });

    return (
        <PageHoc>
            <main className={styles.main}>
                <div>
                    <h4>Página de Menus</h4>
                    <div className="d-flex">
                        {apresentaMenu}
                    </div>
                    <hr />
                    {warning && <p style={{ color: "red" }}>Por favor, selecione pelo menos um item antes de comprar.</p>}
                    {showForm ? (
                        <form onSubmit={handleSubmit}>
                            <div>
                                <label>Nome: </label>
                                <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
                            </div>
                            <button type="submit" className="btn btn-primary">Submeter</button>
                        </form>
                    ) : (
                        confirmation ? (
                            <div>
                                <center>
                                    <h5>Pedido enviado com sucesso!</h5>
                                    <Link href="/" className="btn btn-primary">Voltar</Link>
                                </center>
                            </div>
                        ) : (
                            <center>
                                <button onClick={handleComprar} className="btn btn-primary">Comprar</button> <br /><br />
                                <Link href="/" className="btn btn-primary">Home</Link>
                            </center>
                        )
                    )}
                </div>
            </main>
        </PageHoc>
    );
}

export default Page;
