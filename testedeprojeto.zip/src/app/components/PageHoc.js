import "bootstrap/dist/css/bootstrap.min.css";

const PageHoc = ({ children }) => {
    return  <>
        {children}
    </> 
}

export default PageHoc