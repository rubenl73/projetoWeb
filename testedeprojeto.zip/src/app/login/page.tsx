'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { loginUser } from '../auth/auth.js';
import React, { FormEvent } from 'react';


export default function LoginPage() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const router = useRouter();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await loginUser(username, password);
            router.push('/list');
        }catch (error) {
            setError('Erro de login. Verifique as suas credenciais.');
        }
    };

    const HomeClick = () => {
        router.push('/');
    };

    return (
        <div>
            <h1>Login</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="username">Utilizador:</label>
                    <input
                        type="text"
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                </div>
                <div>
                    <label htmlFor="password">Senha:</label>
                    <input 
                        type="password" 
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>
                <button type="submit">Entrar</button> <br/>
                <button onClick={HomeClick}>Home</button> 
            </form>
        </div>
    );
}