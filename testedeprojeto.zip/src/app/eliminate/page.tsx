'use client';

import { useState } from 'react';
import axios from 'axios';
import { useRouter } from "next/navigation";

export default function EliminarProdutoPage() {
    const router = useRouter();
    const ListClick = () => {
        router.push('/list');
    };


    const [id, setId] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError(''); // Reset error message

        try {
            const response = await axios.delete(`http://localhost:1337/api/menus/${id}`);

            console.log('Produto eliminado:', response.data);

            setId('');
        } catch (error) {
            if (error.response && error.response.status === 404) {
                setError('Produto não encontrado. Verifique o ID e tente novamente.');
            } else {
                setError('Erro ao eliminar o produto. Tente novamente mais tarde.');
            }
            console.error('Erro ao eliminar o produto:', error);
        }
    };

    return (
        <div>
            <h1>Eliminar Produto</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor='id'>ID do Produto:</label>
                    <input
                        type="text"
                        id="id"
                        value={id}
                        onChange={(e) => setId(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Eliminar</button> <br></br>
                <button onClick={ListClick}>Voltar</button>
            </form>
            {error && <p style={{ color: 'red' }}>{error}</p>}
        </div>
    );
}
