'use client';

import { useEffect, useState } from "react";
import axios from "axios";
import { useRouter } from "next/navigation";

interface Menu {
    id: number;
    attributes: {
        Titulo: String;
        descricao: String;
        disponivel: Boolean;
        criacaoProduto: Date;
        createdAt: String;
        updatedAt: String;
        publishedAt: String;
        preco: String;
    };
}

export default function ProdutoPage() {
    const router = useRouter();

    const CreateClick = () => {
        router.push('/create');
    };

    const EliminateClick = () => {
        router.push('/eliminate');
    };

    const OrdersClick = () => {
        router.push('/orders');
    };

    const HomeClick = () => {
        router.push('/');
    };

    const logoutUser = () => {
        // Remover o token de autenticação do localStorage
        localStorage.removeItem('token');
        // Redirecionar para a página inicial
        router.push('/');
    };

    const [menus, setMenus] = useState<Menu[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchMenus = async () => {
            try {
                const response = await axios.get<{ data: Menu[] }>
                    ('http://localhost:1337/api/menus');
                setMenus(response.data.data);
                setLoading(false);
            } catch (error) {
                console.error('Erro ao buscar os produtos:', error);
                setLoading(false);
            }
        };

        fetchMenus();
    }, []);

    return (
        <div>
            <h1>Lista de Produtos</h1>
            {loading ? (
                <p>Carregando...</p>
            ) : (
                Array.isArray(menus) && menus.map((menu) => (
                    <div key={menu.id}>
                        <h2>{menu.attributes.Titulo}</h2>
                        <p>Id: {menu.id}</p>
                        <p>{menu.attributes.descricao}</p>
                        <p>Preço: {menu.attributes.preco}€</p>
                    </div>
                ))
            )}
            <button onClick={CreateClick}>Criar um produto</button> <br/>
            <button onClick={EliminateClick}>Eliminar um produto</button> <br/>
            <button onClick={OrdersClick}>Pedidos pendentes</button> <br/>
            <button onClick={HomeClick}>Home</button> <br/>
            <button onClick={logoutUser}>Logout</button>
        </div>
    );
}
