import React from 'react';
import Head from 'next/head';
import styles from '../styles/sobre-nos.module.css';
import Link from 'next/link';

export default function SobreNos() {
  return (
    <>
      <Head>
        <title>Sobre Nós - Food Truck</title>
        <meta name="description" content="Saiba mais sobre o nosso Food Truck e a nossa missão." />
      </Head>
      <div className={styles.container}>
        <header className={styles.header}>
          <h1>Sobre Nós</h1>
        </header>
        <section className={styles.content}>
          <p>
            Bem-vindo ao nosso Food Truck! Aqui temos comida deliciosa e por oferecer a melhor experiência gastronómica na rua. 
            O nosso objetivo é proporcionar refeições saborosas e memoráveis a todos os nossos clientes.
          </p>
          <p>
            Utilizamos apenas os melhores ingredientes e preparamos tudo com dedicação. Desde hambúrgueres suculentos até ás melhores batatas, temos algo para satisfazer todos os gostos.
          </p>
          <p>
            Obrigado por nos visitar e esperamos vê-lo em breve no nosso Food Truck!
          </p>
        </section>
        <center>
          <Link href="/" className={styles.menuButton}>Home</Link>
        </center>
      </div>
    </>
  );
}
