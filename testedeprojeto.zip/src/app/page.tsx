'use client';

import Head from 'next/head';
import styles from './styles/Home.module.css';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { logoutUser } from './auth/auth';


export default function Home() {
  const router = useRouter();

  const handleLogout = () => {
    logoutUser();
    router.push('/login');
  }
  
  return (
    <div className={styles.container}>
      <Head>
        <title>FoodTruck RK</title>
        <meta name="description" content="Visite o FoodTruck RK para os melhores lanches!" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <header className={styles.header}>
        <img src="/logo.png" alt="Logotipo do FoodTruck RK" className={styles.logo} />
        <h1>FoodTruck RK</h1> 
        <br></br>
        <button type='button' onClick={handleLogout} className={styles.loginButton}>
          Admin Login
        </button>
      </header>

      <main className={styles.main}>
        <section className={styles.about}>
          <h2>Saudações</h2>
          <p>Encontre sabores incríveis e uma experiência gastronômica única no foodtruck RK. 
            Preparamos comida de rua com qualidade e um toque especial.</p>
        </section>

        <section className={styles.info}>
          <h2>Horário de Funcionamento:</h2>
          <p>Segunda a Quinta: 11h às 22h</p>
          <p>Sexta e Sábado: 12h às 24h</p>
        </section>

        <Link href="/menus" className={styles.menuButton}>Pedir Menu</Link>
      </main>

      <footer className={styles.footer}>
        <p>Visite-nos e experimente as nossas especialidades. Na sua rua mais próxima!</p>
        <br></br>
        <Link href="/sobre-nos" className={styles.menuButton}>Sobre Nos</Link>
      </footer>
    </div>
  )
}
