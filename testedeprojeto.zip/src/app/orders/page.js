"use client";

import PageHoc from "../components/PageHoc";
import styles from "../page.module.css";
import { useEffect, useState } from "react";
import Link from 'next/link';

const Orders = () => {
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        fetch("http://localhost:1337/api/pedidos?populate=menus")
            .then(res => res.json())
            .then((res) => setOrders(res.data))
            .catch(error => console.error("Erro ao buscar pedidos:", error));
    }, []);

    const updateOrderStatus = (id, status) => {
        console.log(`Atualizando pedido ${id} para status ${status}`);
        fetch(`http://localhost:1337/api/pedidos/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ data: { status } })
        })
        .then((res) => {
            if (res.ok) {
                setOrders(orders.map(order => {
                    if (order.id === id) {
                        return { ...order, attributes: { ...order.attributes, status } };
                    }
                    return order;
                }));
                console.log(`Pedido ${id} atualizado para status ${status}`);
            } else {
                console.error(`Erro ao atualizar o pedido ${id}:`, res.statusText);
            }
        })
        .catch(error => console.error("Erro na atualização do pedido:", error));
    };

    const removeOrder = (id) => {
        console.log(`Removendo pedido ${id}`);
        fetch(`http://localhost:1337/api/pedidos/${id}`, {
            method: "DELETE"
        })
        .then((res) => {
            if (res.ok) {
                setOrders(orders.filter(order => order.id !== id));
                console.log(`Pedido ${id} removido com sucesso`);
            } else {
                console.error(`Erro ao remover o pedido ${id}:`, res.statusText);
            }
        })
        .catch(error => console.error("Erro ao remover o pedido:", error));
    };

    const apresentaPedidos = orders.length === 0 ? <p>Nenhum pedido recebido ainda.</p> : orders.map((order) => (
        <div key={order.id} className="card m-4" style={{ width: "18rem" }}>
            <div className="card-body">
                <h5 className="card-title">Pedido de {order.attributes.Nome}</h5>
                <ul>
                    {order.attributes.menus.data.map(menu => (
                        <li key={menu.id}>{menu.attributes.Titulo}</li>
                    ))}
                </ul>
                <div>
                    <button 
                        className="btn btn-success m-1"
                        onClick={() => updateOrderStatus(order.id, 'concluído')}
                    >
                        Concluir
                    </button>
                    <button 
                        className="btn btn-danger m-1"
                        onClick={() => updateOrderStatus(order.id, 'cancelado')}
                    >
                        Cancelar
                    </button>
                    <button 
                        className="btn btn-secondary m-1"
                        onClick={() => removeOrder(order.id)}
                    >
                        Remover
                    </button>
                </div>
                {order.attributes.status && (
                    <p>Status: {order.attributes.status}</p>
                )}
            </div>
        </div>
    ));

    return (
        <PageHoc>
            <main className={styles.main}>
                <div>
                    <h4>Pedidos Recebidos</h4>
                    <div className="d-flex">
                        {apresentaPedidos}
                    </div>
                    <hr />
                    <center>
                        <Link href="/" className="btn btn-primary">Home</Link>
                    </center>
                </div>
            </main>
        </PageHoc>
    );
}

export default Orders;
