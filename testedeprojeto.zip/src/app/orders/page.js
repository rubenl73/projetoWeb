"use client";

import PageHoc from "../components/PageHoc";
import styles from "../page.module.css";
import { useEffect, useState } from "react";
import Link from 'next/link';

const Orders = () => {
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        fetch("http://localhost:1337/api/pedidos?populate=menus")
            .then(res => res.json())
            .then((res) => setOrders(res.data));
    }, []);

    const apresentaPedidos = orders.length === 0 ? <p>Nenhum pedido recebido ainda.</p> : orders.map((order, index) => (
        <div key={order.id} className="card m-4" style={{ width: "18rem" }}>
            <div className="card-body">
                <h5 className="card-title">Pedido de {order.attributes.name}</h5>
                <ul>
                    {order.attributes.menus.data.map(menu => (
                        <li key={menu.id}>{menu.attributes.Titulo}</li>
                    ))}
                </ul>
            </div>
        </div>
    ));

    return (
        <PageHoc>
            <main className={styles.main}>
                <div>
                    <h4>Pedidos Recebidos</h4>
                    <div className="d-flex">
                        {apresentaPedidos}
                    </div>
                    <hr />
                    <center>
                        <Link href="/" className="btn btn-primary">Home</Link>
                    </center>
                </div>
            </main>
        </PageHoc>
    );
}

export default Orders;
